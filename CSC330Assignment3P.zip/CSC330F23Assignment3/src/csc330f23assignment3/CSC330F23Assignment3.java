package csc330f23assignment3;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * @author CSC330F23
 *
 * Assignment 3.
 *
 * This programs implements the Quick Sort algorithm using three different pivot
 * picking strategies.
 *
 * @since October 25, 2023
 *
 * I have followed the UNCG Academic Integrity Policy on this assignment.
 *
 */
public class CSC330F23Assignment3 {

    private static final String[] quickSortPivotMethods = {
        "Middle Element Pivot",
        "Random Pivot", "Median of 3 Pivot"};

    static int[] quickArray;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        runSampleQuickSort();
        runQuickSortBenchMark();

    }

    /**
     * Run quickSort with each pivot picking strategy on the same array of 24
     * integers.
     *
     */
    private static void runSampleQuickSort() {

        int[] quickSortArray = generateIntArray(15);
        System.out.println("QuickSort");
        for (int i = 0; i < quickSortPivotMethods.length; i++) {
            quickArray = quickSortArray.clone();
            System.out.println(quickSortPivotMethods[i]);
            System.out.println(Arrays.toString(quickArray));
            quicksort(quickArray, 0, quickArray.length - 1, i, true);

        }

    }

    /**
     * Recursive quickSort method.
     *
     * @param array - the array to be sorted
     * @param left - the first array index
     * @param right - the last array index
     * @param strategy - the method for picking the pivot
     */
    private static void quicksort(int[] array, int left, int right, int strategy, boolean print) {
        if (left <= right) {
            int pivot = selectPivot(array, left, right, strategy);

            int p = partition(array, left, right, pivot);
            if (print) {
                printArray();
            }

            quicksort(array, left, p - 1, strategy, print);  // Sort small elements
            quicksort(array, p + 1, right, strategy, print); // Sort large elements

        }
    }

    /**
     * Pick array pivot to partition around.
     *
     * @param array - the array to be sorted
     * @param left - the first array index
     * @param right - the last array index
     * @param strategy - the method for picking the pivot
     * @return - the pivot
     */
    private static int selectPivot(int[] array, int left, int right,
            int strategy) {

        switch (strategy) {

            case 0 -> {
                int middle = (left + right) / 2;
                swap(array, middle, right);
                return array[right];

            }
            case 1 -> {
                int p = (int) (Math.random() * (right - left)) + left;
                swap(array, p, right);
                return array[right];

            }
            case 2 -> {
                return medianOf3(array, left, right);
            }

            default ->
                throw new AssertionError("Invalid Pivot Strategy");
        }

    }

    /**
     * Partition the array into two sub-arrays.
     *
     * @param array - the array to be sorted
     * @param left - the first array index
     * @param right - the last array index
     * @param pivot - the pivot for partitioning.
     * @return - the partitioned array
     */
    private static int partition(int[] array, int left, int right, int pivot) {
        int i = left - 1;
        int j = right;

        while (i < j) {
            do {
                i++;
            } while ((i <= right) && array[i] < pivot);
            do {
                j--;
            } while ((j >= left) && array[j] > pivot);
            if (i < j) {
                swap(array, i, j);
            }
        }
        swap(array, i, right);
        return i;
    }

    /**
     * Find the pivot as a median of three elements of the array.
     *
     * @param array - The array containing the elements
     * @param left - The first element index
     * @param right - The last element index
     * @return - the pivot
     */
    private static int medianOf3(int[] array, int left, int right) {

        int center = (left + right) / 2;
        if (array[center] < array[left]) {
            swap(array, left, center);
        }
        if (array[right] < array[left]) {
            swap(array, left, right);
        }
        if (array[right] < array[center]) {
            swap(array, center, right);
        }
        //place pivot at position right-1
        swap(array, center, right);
        return array[right];
    }

    /**
     * Compare the performances of the different pivot picking strategies on
     * increasing array sizes.
     *
     * @return the best performing strategy.
     */
    private static void runQuickSortBenchMark() {
        System.out.println("\n***Quick Sort BenchMark***");
        System.out.println("***Milliseconds***");
        System.out.printf("\n%-10s%-15s%-15s%-15s\n", "N", "Middle", "Random",
                "Median of 3");

        double[] runningTimes = new double[quickSortPivotMethods.length];
        final int NUM_TRIALS = 3;
        Arrays.fill(runningTimes, 0l);
        List< int[]> listofIntArrays = new ArrayList<>();

        //I wanted to sort the same N sized arrays for all the strategies.
        for (int p = 0; p < 20; p++) {
            int arraySize = (int) (Math.pow(2, p + 4));
            int[] intArray = generateIntArray(arraySize);
            listofIntArrays.add(intArray);
        }

        for (int j = 0; j < listofIntArrays.size(); j++) {
            int[] currentArray = listofIntArrays.get(j);
            System.out.printf("%-10d", currentArray.length);
            for (int i = 0; i < quickSortPivotMethods.length; i++) {
                for (int k = 0; k < NUM_TRIALS; k++) { //Run 3 trials

                    int[] intArray = currentArray.clone();
                    Instant start = Instant.now();
                    quicksort(intArray, 0, intArray.length - 1, i, false);
                    Instant stop = Instant.now();
                    long timeElapsedQSort = Duration.between(start, stop).toNanos();

                    runningTimes[i] += timeElapsedQSort;
                }
                System.out.printf("%-15.3f", runningTimes[i] / 1000000.0);
            }
            System.out.println("");
        }

        System.out.println(
                "Fastest QuickSort on average: " + quickSortPivotMethods[minIndex(
                        runningTimes, NUM_TRIALS)]);

    }

    /**
     * Utility method for swapping two array elements.
     *
     * @param array - The array containing the elements
     * @param first - The first element index
     * @param second - The second element index
     */
    private static void swap(int[] array, int first, int second) {

        int temp = array[first];
        array[first] = array[second];
        array[second] = temp;
    }

    /**
     * Utility method to generate an array of random integers.
     *
     * @param n - The size of the generated array.
     * @return
     */
    private static int[] generateIntArray(int n) {

        int minVal = 1;
        int maxVal = 100;

        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = ThreadLocalRandom.current().nextInt(minVal, maxVal);
        }
        return arr;
    }

    /**
     * Utility method to find the array index with the smallest average value.
     *
     * @param array
     * @param NUM_TRIALS
     * @return - the array index containing the smallest average value.
     */
    public static int minIndex(double[] array, int NUM_TRIALS) {

        for (int i = 0; i < array.length; i++) {
            array[i] = array[i] / NUM_TRIALS;
        }
        int minIndex = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[minIndex] > array[i]) {
                minIndex = i;
            }
        }
        return minIndex;
    }

    private static void printArray() {
        System.out.println(Arrays.toString(quickArray));
    }

}
