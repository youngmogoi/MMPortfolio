package csc330assignment4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * Assignment 4.
 *
 * This programs implements the BFS algorithm by building a graph from adjacency
 * list text file.
 *
 * @since November 16, 2023
 *
 * I have followed the UNCG Academic Integrity Policy on this assignment. *
 *
 * @author CSC330-F23
 */
public class CSC330Assignment4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String graphFile = getUserFileInput();
        int source = getBFSSource(graphFile);

        Graph g = buildGraph(graphFile);
        g.printGraph();

        System.out.println("Minimum distances from " + source + " ");
        System.out.println(Arrays.toString(g.BFS(source)));

    }

    /**
     * Prompt the user for a file to use.
     *
     * @return the file name.
     */
    private static String getUserFileInput() {

        System.out.println("Enter file to test with. Choose one of the following:");
        System.out.println("1: input1.txt");
        System.out.println("2: input2.txt");
        System.out.println("3: input3.txt");
        Scanner scan = new Scanner(System.in);

        int userInput = scan.nextInt();

        switch (userInput) {
            case 1 -> {
                return "input1.txt";
            }
            case 2 -> {
                return "input2.txt";
            }
            case 3 -> {
                return "input3.txt";
            }
            default -> {
                return "input1.txt";
            }
        }

    }

    /**
     * Get the source vertex for the BFS traversal.
     *
     * @param fileName
     * @return the source vertex
     */
    private static int getBFSSource(String fileName) {

        try {
            Scanner in = new Scanner(new File(fileName));
            return in.nextInt();
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found!");
        }
        return 0;
    }

    /**
     * Build the graph from the file.
     *
     * @param fileName
     * @return the graph.
     */
    private static Graph buildGraph(String fileName) {
        Graph g = new Graph();
        try {
            Scanner in = new Scanner(new File(fileName));
            in.useDelimiter("\\n");
            in.nextLine();
            int vertex = 0;
            while (in.hasNext()) {
                g.addVertex(vertex);
                String[] tokens = in.nextLine().split("\\s+");
                for (String token : tokens) {
                    g.addEdge(vertex, Integer.parseInt(token.trim()));
                }

                vertex += 1;
            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found!");
        }
        return g;
    }

}
