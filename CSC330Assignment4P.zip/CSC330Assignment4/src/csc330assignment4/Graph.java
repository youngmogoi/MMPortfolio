package csc330assignment4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 *
 * Implements a graph using an adjacency list.
 *
 * @author CSC330-F23
 */
class Graph {

    private final Map<Integer, List<Integer>> adjacencyList = new HashMap<>();

    /**
     * Create a new vertex.
     *
     * @param vertex
     */
    void addVertex(int vertex) {

        adjacencyList.putIfAbsent(vertex, new ArrayList<>());
    }

    /**
     * Add an edge in the adjacency list.
     *
     * @param source
     * @param destination
     */
    void addEdge(int source, int destination) {

        adjacencyList.get(source).add(destination);

    }

    /**
     * Perform a BFS on a graph and calculate the minimum distances from a
     * source.
     *
     * @param source the starting point of the BFS
     * @return the list of minimum distances for each node.
     *
     */
    int[] BFS(int source) {
        Queue<Integer> queue = new LinkedList<>();
        boolean[] visited = new boolean[adjacencyList.size()];
        int[] distances = new int[adjacencyList.size()];
        Arrays.fill(distances, -1);

        distances[source] = 0;
        visited[source] = true;
        queue.add(source);

        while (!queue.isEmpty()) {
            int current = queue.poll();
            for (int neighbor : adjacencyList.get(current)) {
                if (!visited[neighbor]) {
                    visited[neighbor] = true;
                    queue.add(neighbor);
                    distances[neighbor] = distances[current] + 1;
                }
            }
        }

        return distances;

    }

    /**
     * Print the graph.
     *
     */
    public void printGraph() {
        for (int key : adjacencyList.keySet()) {
            System.out.print(key + " -->");
            System.out.println(adjacencyList.get(key).toString());
        }
    }
}
