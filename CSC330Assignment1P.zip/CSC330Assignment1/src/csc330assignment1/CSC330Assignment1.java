package csc330assignment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 * @author CSC330F23. 
 * Assignment 1.
 *
 * Maintains lists of Person objects and prints them to the console.
 * @since August 25, 2023.
 *
 * I have followed the UNCG Academic Integrity Policy on this assignment.
 */
public class CSC330Assignment1 {

    private static List<Person> studentList, hourlyList, permanentList;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        studentList = new ArrayList<>();
        hourlyList = new ArrayList<>();
        permanentList = new ArrayList<>();
        testSamples();
        readFile();
        printArrayLists();
        displayPayStubs();

    }

    /**
     * Test sample Person objects.
     */
    private static void testSamples() {
        Person p = new Student(3.5, 3, "Bio", "S123456", "Sample S",
                new Date("1998/12/25"));

        System.out.println(p);

        Person q = new Hourly(15, 38, "sales", "H123456", "Sample H",
                new Date("2001/08/13"));
        System.out.println(q);

        Person r = new Permanent(68000, new Date("2021/08/13"), "marketing",
                "P895623", "Sample P",
                new Date("1994/04/21"));
        System.out.println(r);
    }

    /**
     * Read <i>people.txt</i> file in a loop and create Person objects.
     */
    private static void readFile() {

        final String FILE_NAME = "people.txt";
        try {
            Scanner in = new Scanner(new File(FILE_NAME));
            in.useDelimiter(",|\\n");

            while (in.hasNext()) {
                Person p;

                String idNumber = in.next().trim();
                String name = in.next().trim();
                Date dateOfBirth = new Date(in.next().trim());

                switch (String.valueOf(idNumber.charAt(0))) {
                    case "S" -> {
                        double gpa = Double.parseDouble(in.next().trim());
                        int rank = Integer.parseInt(in.next().trim());
                        String major = in.next().trim();
                        p = new Student(gpa, rank, major, idNumber, name,
                                dateOfBirth);
                        studentList.add(p);
                    }
                    case "H" -> {
                        String department = in.next().trim();
                        double wage = Double.parseDouble(in.next().trim());
                        double weeklyHours = Double.parseDouble(in.next().trim());
                        p = new Hourly(wage, weeklyHours, department, idNumber,
                                name,
                                dateOfBirth);
                        hourlyList.add(p);
                    }
                    case "P" -> {
                        String department = in.next().trim();
                        double salary = Double.parseDouble(
                                in.next().trim().substring(1));
                        Date hireDate = new Date(in.next().trim());
                        p = new Permanent(salary, hireDate, department, idNumber,
                                name, dateOfBirth);
                        permanentList.add(p);
                    }
                    default ->
                        throw new AssertionError("Error parsing file");
                }

            }
        } catch (FileNotFoundException ex) {
            System.out.println("File Not Found!");
        }

    }

    /**
     * Print lists in tabular format.
     */
    private static void printArrayLists() {
        System.out.println("\n\nSTUDENTS");
        System.out.println(
                "-------------------------------------------------------"
                + "---------------------------------------------------");
        for (Person person : studentList) {
            System.out.println(person);
        }

        System.out.println("\n\nHOURLY");
        System.out.println(
                "-------------------------------------------------------------------"
                + "--------------------------------------------------------");
        for (Person person : hourlyList) {
            System.out.println(person);
        }

        System.out.println("\n\nPERMANENT");
        System.out.println(
                "--------------------------------------------------------------------"
                + "---------------------------------------------------------------");
        for (Person person : permanentList) {
            System.out.println(person);
        }

    }

    /**
     * Show pay stubs for Employee objects.
     */
    private static void displayPayStubs() {
        System.out.println("\n");
        hourlyList.forEach(person -> {
            Hourly hourlyEmpl = (Hourly) person;
            hourlyEmpl.displayPayStub();
        });

        System.out.println("\n");
        permanentList.forEach(person -> {
            Permanent permEmpl = (Permanent) person;
            permEmpl.displayPayStub();
        });

    }

}
