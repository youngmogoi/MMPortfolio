package csc330assignment1;

import java.util.Date;

/**
 * Maintains the Person class details.
 *
 * @author CSC330F23.
 */
public class Person {

    protected String idNumber;
    protected String name;
    protected Date dateOfBirth;

    public Person(String idNumber, String name, Date dateOfBirth) {
        this.idNumber = idNumber;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
    }

}
