package csc330assignment1;

/**
 * Provides methods for employee payroll.
 *
 * @author CSC330F23.
 */
interface Payroll {

    /**
     * Calculate weekly paycheck of an Employee
     *
     * @return the paycheck amount.
     */
    public double calculateWeeklyPay();

    /**
     * Display the paystub for a given Employee.
     */
    public void displayPayStub();
}
