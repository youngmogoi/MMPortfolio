package csc330assignment1;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Maintains the Permanent Employee class details.
 *
 * @author CSC330F23.
 */
public class Permanent extends Employee {

    private double salary;
    private Date hireDate;

    public Permanent(double salary, Date hireDate, String department,
            String idNumber, String name, Date dateOfBirth) {
        super(department, idNumber, name, dateOfBirth);
        this.salary = salary;
        this.hireDate = hireDate;
    }

    @Override
    public void displayPayStub() {
        System.out.println(
                "Permanent Employee: " + name + "| Annual salary: $" + this.salary
                + "| Pay Check: $" + "%5.2f".formatted(calculateWeeklyPay()));

    }

    @Override
    public double calculateWeeklyPay() {
        return this.salary / 52;
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        String dateOfBirthString = sdf.format(dateOfBirth);
        String hireDateString = sdf.format(hireDate);
        return "| Permanent| name: " + "%-20s".formatted(name) + "| DOB: "
                + dateOfBirthString
                + "| dep: " + "%-25s".formatted(department)
                + "| salary: " + "%10.2f".formatted(salary) + "| hireDate: "
                + hireDateString + '|';
    }

}
