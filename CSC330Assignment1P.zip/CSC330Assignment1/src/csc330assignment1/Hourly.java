package csc330assignment1;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Maintains the Hourly Employee class details.
 *
 * @author CSC330F23.
 */
public class Hourly extends Employee {

    private double wage;
    private double weeklyHours;

    public Hourly(double wage, double weeklyHours, String department,
            String idNumber, String name, Date dateOfBirth) {
        super(department, idNumber, name, dateOfBirth);
        this.wage = wage;
        this.weeklyHours = weeklyHours;
    }

    @Override
    public void displayPayStub() {
        System.out.println(
                "Hourly Employee: " + name + "| Wage: $" + wage
                + "/hr| Hours: " + weeklyHours + " Pay Check: $" + "%5.2f".formatted(
                        calculateWeeklyPay()));

    }

    @Override
    public double calculateWeeklyPay() {
        double basePay, overtime = 0;
        if (weeklyHours > 40) {
            basePay = 40 * wage;
            overtime = 1.5 * wage * (weeklyHours - 40);
        } else {
            basePay = weeklyHours * wage;
        }
        return basePay + overtime;

    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        String dateOfBirthString = sdf.format(dateOfBirth);
        return "| Hourly|" + "%-20s".formatted(name) + "| ID:" + idNumber + "| DOB: " + dateOfBirthString
                + "| dep: " + "%-25s".formatted(department) + "| wage: " + "%.2f".formatted(
                wage)
                + "| weeklyHours: " + "%5.2f".formatted(weeklyHours) + '|';
    }

}
