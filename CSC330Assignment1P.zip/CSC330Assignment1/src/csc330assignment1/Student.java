package csc330assignment1;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Maintains the Student class details.
 *
 * @author CSC330F23.
 */
public class Student extends Person {

    private double gpa;
    private int rank;
    private String major;

    public Student(double gpa, int rank, String major, String idNumber,
            String name, Date dateOfBirth) {
        super(idNumber, name, dateOfBirth);
        this.gpa = gpa;
        this.rank = rank;
        this.major = major;
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        String dateOfBirthString = sdf.format(dateOfBirth);
        return "| Student|" + "%-20s".formatted(name) + "| ID:" + idNumber + "| DOB:"
                + dateOfBirthString + "| gpa: " + gpa
                + "| rank: " + rank + "| major: " + "%-20s".formatted(major) + "|";
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

}
