package csc330assignment1;

import java.util.Date;

/**
 * Maintains the Employee class details.
 *
 * @author CSC330F23.
 */
public abstract class Employee extends Person implements Payroll {

    protected String department;

    public Employee(String department, String idNumber, String name,
            Date dateOfBirth) {
        super(idNumber, name, dateOfBirth);
        this.department = department;
    }

    @Override
    public abstract double calculateWeeklyPay();

    @Override
    public abstract void displayPayStub();

}
